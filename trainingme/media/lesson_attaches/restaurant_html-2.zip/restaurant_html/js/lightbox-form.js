function openbox()
{
	$('#box').fadeIn(1000);
	$('#filter').fadeIn(1000);
}
function closebox()
{
	$('#box').fadeOut(1000);
	$('#filter').fadeOut(1000);
}

function emptyText (el , value){
	if(el.value==value){
		el.value='';
	}
}
function resetText (el , value){
	if(el.value==''){
		el.value=value;
	}
}
